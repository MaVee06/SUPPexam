# Women-Safety Hotspots in Ekurhuleni — Streamlit Dashboard

## Files to place beside `app.py`
- `ekurhuleni_hotspot_classification_predictions.csv` — produced by the classification notebook.
- `ekurhuleni_ml_cluster_results.csv` — your existing K-Means station results.
- `police_station_coordinates.csv` — OpenAfrica station coordinates with station name, longitude, latitude columns.

The app also lets you upload each CSV from the sidebar if the file is not in the same folder.

## Run on Windows
1. Install Python 3.12 or 3.13 from https://www.python.org/downloads/windows/
2. Open Command Prompt and change to this folder, for example:
   `cd %USERPROFILE%\Desktop\WomenSafetyDashboard`
3. Create and activate a virtual environment:
   `py -3.12 -m venv .venv`
   `.venv\Scripts\activate`
4. Install requirements:
   `python -m pip install --upgrade pip`
   `python -m pip install -r requirements.txt`
5. Run:
   `python -m streamlit run app.py`

If you installed Python 3.13, use `py -3.13` instead of `py -3.12`.

## Create the prediction CSV in Colab
The classification notebook should save:
`/content/ekurhuleni_hotspot_classification_predictions.csv`

Download that CSV from Colab and place it in this folder. Rename your OpenAfrica coordinates CSV to `police_station_coordinates.csv` and place it here too. Copy your K-Means output CSV here as `ekurhuleni_ml_cluster_results.csv`.

## Important
The map plots police-station coordinates, not incident locations. Hotspot labels indicate relatively high recorded sexual-offence counts, not proof a station area is unsafe.
