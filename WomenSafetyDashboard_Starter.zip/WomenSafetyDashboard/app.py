from pathlib import Path
import re
import numpy as np
import pandas as pd
import streamlit as st

try:
    import folium
    from streamlit_folium import st_folium
except ImportError:
    folium = None
    st_folium = None

st.set_page_config(
    page_title="Ekurhuleni Women-Safety Hotspots",
    page_icon="🗺️",
    layout="wide"
)

st.title("🗺️ Women-Safety Hotspots in Ekurhuleni")
st.caption(
    "Exploratory analysis of recorded police-station crime counts. "
    "This dashboard does not identify exact incident locations or prove that a place is safe or unsafe."
)

ROOT = Path(__file__).resolve().parent

def read_csv_or_upload(filename, label):
    """Load a local CSV first; otherwise let the user upload it."""
    local_path = ROOT / filename
    if local_path.exists():
        try:
            return pd.read_csv(local_path), f"Loaded {filename}"
        except Exception as exc:
            st.warning(f"Could not read {filename}: {exc}")

    uploaded = st.sidebar.file_uploader(
        label,
        type=["csv"],
        key=f"upload_{filename}"
    )
    if uploaded is not None:
        try:
            return pd.read_csv(uploaded), f"Uploaded {uploaded.name}"
        except Exception as exc:
            st.error(f"Could not read uploaded file: {exc}")
    return None, f"Not found: {filename}"

def normalise_station(series):
    return series.astype(str).str.strip().str.casefold()

def find_column(df, options):
    lookup = {str(c).strip().casefold(): c for c in df.columns}
    for option in options:
        if option.casefold() in lookup:
            return lookup[option.casefold()]
    return None

def coerce_date(series):
    return pd.to_datetime(series, errors="coerce")

# File inputs
st.sidebar.header("Data files")
pred_df, pred_status = read_csv_or_upload(
    "ekurhuleni_hotspot_classification_predictions.csv",
    "Upload classification predictions CSV"
)
cluster_df, cluster_status = read_csv_or_upload(
    "ekurhuleni_ml_cluster_results.csv",
    "Upload K-Means cluster results CSV"
)
coords_df, coords_status = read_csv_or_upload(
    "police_station_coordinates.csv",
    "Upload police station coordinates CSV"
)

with st.expander("Data file status", expanded=(pred_df is None or coords_df is None)):
    st.write(pred_status)
    st.write(cluster_status)
    st.write(coords_status)
    st.markdown(
        "Place the CSV files beside `app.py`, or upload them in the sidebar. "
        "The coordinates file should contain station name, longitude and latitude columns."
    )

# Validate and harmonise classification data
if pred_df is not None:
    station_col = find_column(pred_df, ["station", "station_name", "compnt_nm"])
    date_col = find_column(pred_df, ["date", "month", "reporting_month"])
    target_col = find_column(pred_df, ["hotspot", "actual_hotspot", "target"])
    sexual_col = find_column(
        pred_df,
        ["sexual_offence_total", "sexual_offences", "rape_and_sexual_assault"]
    )
    pred_col = find_column(
        pred_df,
        ["predicted_hotspot_logistic", "predicted_hotspot", "prediction", "predicted_hotspot_random_forest"]
    )

    required = [station_col, date_col]
    if not all(required):
        st.error(
            "The predictions CSV needs a station column and a date column. "
            "Use the CSV produced by the classification notebook."
        )
        pred_df = None
    else:
        pred_df = pred_df.copy()
        pred_df["station_display"] = pred_df[station_col].astype(str).str.strip()
        pred_df["date_display"] = coerce_date(pred_df[date_col])
        pred_df = pred_df.dropna(subset=["date_display"])
        if target_col:
            pred_df["actual_hotspot"] = pd.to_numeric(
                pred_df[target_col], errors="coerce"
            )
        if sexual_col:
            pred_df["sexual_offence_count"] = pd.to_numeric(
                pred_df[sexual_col], errors="coerce"
            )
        if pred_col:
            pred_df["predicted_hotspot"] = pd.to_numeric(
                pred_df[pred_col], errors="coerce"
            )

# Validate and harmonise cluster data
if cluster_df is not None:
    c_station = find_column(cluster_df, ["station", "station_name"])
    c_cluster = find_column(cluster_df, ["cluster", "cluster_label", "kmeans_cluster"])
    if c_station and c_cluster:
        cluster_df = cluster_df.copy()
        cluster_df["station_display"] = cluster_df[c_station].astype(str).str.strip()
        cluster_df["cluster_display"] = cluster_df[c_cluster].astype(str)
    else:
        st.warning(
            "The cluster CSV needs columns named `station` and `cluster` "
            "(or equivalent station/cluster label columns)."
        )
        cluster_df = None

# Validate and harmonise coordinate data
if coords_df is not None:
    coord_station = find_column(
        coords_df, ["compnt_nm", "station", "station_name", "component_name"]
    )
    lon_col = find_column(coords_df, ["location_x", "longitude", "lon", "long"])
    lat_col = find_column(coords_df, ["location_y", "latitude", "lat"])
    if coord_station and lon_col and lat_col:
        coords_df = coords_df.copy()
        coords_df["station_display"] = coords_df[coord_station].astype(str).str.strip()
        coords_df["station_key"] = normalise_station(coords_df["station_display"])
        coords_df["longitude"] = pd.to_numeric(coords_df[lon_col], errors="coerce")
        coords_df["latitude"] = pd.to_numeric(coords_df[lat_col], errors="coerce")
        coords_df = coords_df.dropna(subset=["longitude", "latitude"])
    else:
        st.warning(
            "Coordinates CSV needs station name, longitude and latitude columns. "
            "For your OpenAfrica file these are usually `compnt_nm`, `location_x`, `location_y`."
        )
        coords_df = None

if pred_df is None:
    st.info(
        "Upload `ekurhuleni_hotspot_classification_predictions.csv` to display "
        "classification results. You can still inspect available cluster data below."
    )

if pred_df is not None:
    # Filters
    st.sidebar.header("Dashboard filters")
    stations = sorted(pred_df["station_display"].dropna().unique().tolist())
    chosen_stations = st.sidebar.multiselect(
        "Police stations",
        options=stations,
        default=stations
    )
    min_date = pred_df["date_display"].min().date()
    max_date = pred_df["date_display"].max().date()
    date_range = st.sidebar.date_input(
        "Date range",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date
    )
    if isinstance(date_range, tuple) and len(date_range) == 2:
        start_date, end_date = pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1])
    else:
        start_date = end_date = pd.Timestamp(date_range)

    filtered = pred_df[
        pred_df["station_display"].isin(chosen_stations)
        & pred_df["date_display"].between(start_date, end_date)
    ].copy()

    # Metrics
    a, b, c, d = st.columns(4)
    a.metric("Station-month records", f"{len(filtered):,}")
    if "actual_hotspot" in filtered:
        a_hot = int((filtered["actual_hotspot"] == 1).sum())
        b.metric("Labelled hotspot records", f"{a_hot:,}")
    else:
        b.metric("Labelled hotspot records", "Not supplied")
    if "predicted_hotspot" in filtered:
        p_hot = int((filtered["predicted_hotspot"] == 1).sum())
        c.metric("Predicted hotspot records", f"{p_hot:,}")
    else:
        c.metric("Predicted hotspot records", "No prediction column")
    if "sexual_offence_count" in filtered and len(filtered):
        d.metric(
            "Recorded rape + sexual assault",
            f"{filtered['sexual_offence_count'].sum():,.0f}"
        )
    else:
        d.metric("Recorded rape + sexual assault", "Not supplied")

    st.subheader("Hotspot classification results")
    if "predicted_hotspot" in filtered:
        pred_label = filtered["predicted_hotspot"].map(
            {1: "Predicted hotspot", 0: "Not predicted"}
        ).fillna("Unknown")
        filtered["prediction_label"] = pred_label
        show_cols = ["station_display", "date_display", "prediction_label"]
        if "actual_hotspot" in filtered:
            filtered["actual_label"] = filtered["actual_hotspot"].map(
                {1: "Hotspot", 0: "Not hotspot"}
            ).fillna("Unknown")
            show_cols.append("actual_label")
        if "sexual_offence_count" in filtered:
            show_cols.append("sexual_offence_count")
        st.dataframe(
            filtered[show_cols].sort_values(
                ["date_display", "station_display"]
            ),
            use_container_width=True,
            hide_index=True
        )
    else:
        st.dataframe(filtered, use_container_width=True, hide_index=True)

    # Monthly chart
    if "sexual_offence_count" in filtered:
        monthly = (
            filtered.groupby("date_display", as_index=False)["sexual_offence_count"]
            .sum()
            .sort_values("date_display")
        )
        st.subheader("Recorded sexual offences over time")
        st.line_chart(
            monthly.set_index("date_display")["sexual_offence_count"],
            y_label="Recorded rape + sexual-assault counts"
        )

    # Map: station locations, not incident locations
    st.subheader("Station map")
    if coords_df is not None and folium is not None and st_folium is not None:
        map_data = filtered.copy()
        map_data["station_key"] = normalise_station(map_data["station_display"])
        latest = (
            map_data.sort_values("date_display")
            .groupby("station_key", as_index=False)
            .tail(1)
        )
        merged = latest.merge(
            coords_df[["station_key", "latitude", "longitude", "station_display"]],
            on="station_key",
            how="left",
            suffixes=("_result", "_coordinate")
        ).dropna(subset=["latitude", "longitude"])

        if not merged.empty:
            center = [
                float(merged["latitude"].mean()),
                float(merged["longitude"].mean())
            ]
            crime_map = folium.Map(location=center, zoom_start=10, control_scale=True)

            for _, row in merged.iterrows():
                if "predicted_hotspot" in row and row["predicted_hotspot"] == 1:
                    color = "red"
                    status = "Predicted hotspot"
                else:
                    color = "blue"
                    status = "Not predicted / no prediction"

                count = row.get("sexual_offence_count", np.nan)
                count_text = (
                    f"{count:.0f}" if pd.notna(count) else "Not available"
                )
                folium.CircleMarker(
                    location=[row["latitude"], row["longitude"]],
                    radius=7,
                    color=color,
                    fill=True,
                    fill_opacity=0.75,
                    popup=(
                        f"<b>{row.get('station_display_result', row.get('station_display', 'Station'))}</b><br>"
                        f"{status}<br>"
                        f"Month: {row['date_display'].strftime('%Y-%m')}<br>"
                        f"Recorded rape + sexual assault: {count_text}"
                    ),
                    tooltip=str(row.get("station_display_result", row.get("station_display", "Station")))
                ).add_to(crime_map)

            st_folium(crime_map, use_container_width=True, height=520)
            st.caption(
                "Map markers show police-station coordinates, not the locations where offences occurred."
            )
        else:
            st.warning("No station names matched between the prediction and coordinate files.")
    else:
        st.info(
            "To display the map, install the map packages and provide the police station coordinates CSV."
        )

# Cluster section
st.divider()
st.subheader("K-Means cluster results")
if cluster_df is not None:
    cluster_stations = sorted(cluster_df["station_display"].unique().tolist())
    selected_cluster_stations = st.multiselect(
        "Filter cluster table by station",
        cluster_stations,
        default=cluster_stations,
        key="cluster_station_filter"
    )
    cluster_view = cluster_df[
        cluster_df["station_display"].isin(selected_cluster_stations)
    ]
    st.dataframe(cluster_view, use_container_width=True, hide_index=True)
else:
    st.info(
        "Add `ekurhuleni_ml_cluster_results.csv` beside `app.py` or upload it in the sidebar "
        "to show your existing K-Means results."
    )

st.divider()
st.markdown(
    "**Interpretation note:** A hotspot label in this project means a station-month had "
    "relatively high recorded rape and sexual-assault counts compared with other stations "
    "in the same month. It is not a verified measure of women's safety, and station coordinates "
    "are not incident locations."
)
